package dev.hardika.taskManagment.taskManagment;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TaskManagmentApplicationTests {

	@Test
	void contextLoads() {
	}

}
