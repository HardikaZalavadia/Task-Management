package dev.hardika.taskManagment.taskManagment;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TaskManagmentApplication {

	public static void main(String[] args) {
		SpringApplication.run(TaskManagmentApplication.class, args);
	}

}
